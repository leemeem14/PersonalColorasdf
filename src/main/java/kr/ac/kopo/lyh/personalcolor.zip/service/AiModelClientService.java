package kr.ac.kopo.lyh.personalcolor.service;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;


@Service
@RequiredArgsConstructor
public class AiModelClientService {
    private final RestTemplate restTemplate;
    @Value("${ai.server.url}") private String aiServerUrl;
    @Value("${app.upload.path:uploads}") private String uploadDir;

    @SneakyThrows
    public Map<String,Object> predictPersonalColor(String storedFileName) {
        Path p = Paths.get(uploadDir).resolve(storedFileName);
        byte[] bytes = Files.readAllBytes(p);
        String base64 = Base64.getEncoder().encodeToString(bytes);

        HttpHeaders h = new HttpHeaders();
        h.setContentType(MediaType.APPLICATION_JSON);
        Map<String,String> body = Map.of("image","data:image/png;base64,"+base64);

        ResponseEntity<Map> r = restTemplate.postForEntity(
                aiServerUrl + "/api/analyze",
                new HttpEntity<>(body,h), Map.class);
        return r.getBody();
    }
}
//@Service
//public class AiModelClientService {
//
//    @Value("${ai.server.url}")
//    private String aiServerUrl;  // ex: http://43.201.28.17:
//
//    private static RestTemplate restTemplate;
//
//    public AiModelClientService(RestTemplate rt) { this.restTemplate = rt; }
//
//    public Map<String, Object> predictPersonalColor(String storedFilePath) {
//        String url = aiServerUrl + "/api/analyze";
//        try {
//            // 파일→Base64
//            byte[] bytes = Files.readAllBytes(Paths.get(storedFilePath));
//            String base64 = Base64.getEncoder().encodeToString(bytes);
//            Map<String,String> body = new HashMap<>();
//            body.put("image", "data:image/png;base64," + base64);
//
//            HttpHeaders headers = new HttpHeaders();
//            headers.setContentType(MediaType.APPLICATION_JSON);
//            HttpEntity<Map<String,String>> req = new HttpEntity<>(body, headers);
//
//            ResponseEntity<Map> resp = restTemplate.postForEntity(url, req, Map.class);
//            if (resp.getStatusCode() == HttpStatus.OK) {
//                return resp.getBody();
//            } else {
//                throw new RuntimeException("Flask 분석 실패: " + resp.getStatusCode());
//            }
//        } catch (Exception e) {
//            throw new RuntimeException("Flask 통신 오류: " + e.getMessage(), e);
//        }
//    }
//}