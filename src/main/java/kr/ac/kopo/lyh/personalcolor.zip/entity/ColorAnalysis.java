package kr.ac.kopo.lyh.personalcolor.entity;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "color_analysis")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ColorAnalysis {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = true)
    private User user;

    @Column(nullable = false)
    private String originalFileName;

    @Column(nullable = false)
    private String storedFileName;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ColorType colorType;

    @Column(length = 1000)
    private String description;

    // 분석 결과 상세 정보
    @Column
    private String dominantColors; // JSON 형태로 저장

    @Column
    private Float confidence; // 분석 신뢰도 (0.0 ~ 1.0)

    @CreationTimestamp
    private LocalDateTime analyzedAt;

    public enum ColorType {
        SPRING_WARM("봄 웜톤", "따뜻하고 생기있는 색상"),
        SUMMER_COOL("여름 쿨톤", "시원하고 우아한 색상"),
        AUTUMN_WARM("가을 웜톤", "깊고 따뜻한 색상"),
        WINTER_COOL("겨울 쿨톤", "선명하고 차가운 색상");

        private final String displayName;
        @Getter
        private final String description;

        ColorType(String displayName, String description) {
            this.displayName = displayName;
            this.description = description;
        }

        @JsonValue
        public String getDisplayName() {
            return displayName;
        }

        /**
         * 주어진 displayName에 매핑되는 ColorType을 반환합니다.
         * 일치하는 타입이 없으면 IllegalArgumentException을 던집니다.
         */
        @JsonCreator
        public static ColorType fromDisplayName(String name) {
            for (ColorType type : ColorType.values()) {
                if (type.displayName.equalsIgnoreCase(name.trim())) {
                    return type;
                }
            }
            throw new IllegalArgumentException("Unknown ColorType displayName: " + name);
        }
    }
}
